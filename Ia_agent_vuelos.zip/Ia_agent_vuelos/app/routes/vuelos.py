from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app import crud, schemas

router = APIRouter(prefix="/flights", tags=["Flights"])

@router.get("/")
def read_flights(db: Session = Depends(get_db)):
    return crud.vuelos.get_flights(db)

@router.post("/")
def create_flight(flight: schemas.vuelos.FlightCreate, db: Session = Depends(get_db)):
    return crud.vuelos.create_flight(db, flight)
