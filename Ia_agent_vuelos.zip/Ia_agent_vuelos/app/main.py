from Fastapi import FastAPI
from app.routes import usuarios

app = FastAPI(title="Agente de Reservas de Vuelos")

app.include_router(usuarios.router)
