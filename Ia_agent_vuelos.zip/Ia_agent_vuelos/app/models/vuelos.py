from sqlalchemy import Column, Integer, String, ForeignKey, Float, DateTime
from sqlalchemy.orm import relationship
from app.config import Base

class Vuelo(Base):
    __tablename__ = "flights"

    id = Column(Integer, primary_key=True, index=True)
    airline_id = Column(Integer, ForeignKey("airlines.id"))
    code = Column(String(20))
    origin = Column(String(100))
    destination = Column(String(100))
    departure_time = Column(DateTime)
    arrival_time = Column(DateTime)
    price = Column(Float)
    available_seats = Column(Integer)

    airline = relationship("Airline", back_populates="flights")
