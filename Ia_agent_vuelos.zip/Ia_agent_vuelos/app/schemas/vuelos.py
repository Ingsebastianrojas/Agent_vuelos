from pydantic import BaseModel
from datetime import datetime

class FlightBase(BaseModel):
    origin: str
    destination: str
    price: float
    departure_time: datetime
    airline: str

class FlightCreate(FlightBase):
    pass

class Flight(FlightBase):
    id: int
    class Config:
        orm_mode = True
