from sqlalchemy.orm import Session
from models import Reservation

def get_user_history(db: Session, user_id: int):
    return db.query(Reservation).filter(Reservation.user_id == user_id).all()
