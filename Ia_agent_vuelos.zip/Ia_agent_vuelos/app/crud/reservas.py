from sqlalchemy.orm import Session
from models import Reservation
from schemas import ReservationCreate

def create_reservation(db: Session, reservation: ReservationCreate):
    db_res = Reservation(**reservation.dict())
    db.add(db_res)
    db.commit()
    db.refresh(db_res)
    return db_res

def get_reservations(db: Session, skip: int = 0, limit: int = 10):
    return db.query(Reservation).offset(skip).limit(limit).all()

def get_reservation_by_id(db: Session, reservation_id: int):
    return db.query(Reservation).filter(Reservation.id == reservation_id).first()

def delete_reservation(db: Session, reservation_id: int):
    res = db.query(Reservation).filter(Reservation.id == reservation_id).first()
    if res:
        db.delete(res)
        db.commit()
    return res