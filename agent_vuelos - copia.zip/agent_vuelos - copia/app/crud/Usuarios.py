from sqlalchemy.orm import Session
from app.models.usuarios import Usuario
from app.schemas.usuarios import UsuarioCreate

def crear_usuario(db: Session, usuario: UsuarioCreate):
    nuevo = Usuario(
        nombre=usuario.nombre,
        email=usuario.email,
        telefono=usuario.telefono,
        password_hash=usuario.password  #encripta la contraseña
    )
    db.add(nuevo)
    db.commit()
    db.refresh(nuevo)
    return nuevo
