from pydantic import BaseModel,EmailStr
from datetime import datetime

class UsuarioCreate(BaseModel):
    nombre:str
    nombre: str
    email: EmailStr
    telefono: str | None = None
    password: str
    
    class UsuarioResponse(BaseModel):
    id_usuario: int
    nombre: str
    email: EmailStr
    telefono: str | None
    fecha_registro: datetime

    class Config:
        orm_mode = True


